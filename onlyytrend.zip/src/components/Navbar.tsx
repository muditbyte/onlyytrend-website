import { ShoppingBag, Search, Menu, User, Wind } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onSearch: (query: string) => void;
}

export default function Navbar({ cartCount, onOpenCart, onSearch }: NavbarProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-lg">
      <div className="container mx-auto flex h-24 items-center justify-between px-4 md:px-12">
        <div className="flex items-center gap-12">
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5 text-brand-muted" />
          </Button>
          <a href="/" className="flex flex-col items-center group">
            <Wind className="h-6 w-6 text-brand-muted mb-0.5 transition-transform group-hover:rotate-12" />
            <span className="font-serif text-2xl text-brand-muted tracking-[0.2em] leading-none">
              ONLYYTREND
            </span>
          </a>
        </div>

        <div className="hidden items-center gap-16 md:flex">
          <a href="#" className="text-[11px] font-sans font-medium tracking-[0.2em] text-brand-muted/70 hover:text-brand-muted transition-colors">COLLECTIONS</a>
          <a href="#" className="text-[11px] font-sans font-medium tracking-[0.2em] text-brand-muted/70 hover:text-brand-muted transition-colors">NEW ARRIVALS</a>
          <a href="#" className="text-[11px] font-sans font-medium tracking-[0.2em] text-brand-muted/70 hover:text-brand-muted transition-colors">BOUTIQUE</a>
          <a href="#" className="text-[11px] font-sans font-medium tracking-[0.2em] text-brand-muted/70 hover:text-brand-muted transition-colors">STORY</a>
        </div>

        <div className="flex items-center gap-4">
          <AnimatePresence>
            {isSearchOpen && (
              <motion.div
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 220, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                className="relative hidden sm:block"
              >
                <Input
                  type="search"
                  placeholder="SEARCH..."
                  className="h-10 w-full rounded-none border-gray-200 bg-transparent px-4 text-[10px] tracking-widest focus-visible:ring-brand-muted"
                  onChange={(e) => onSearch(e.target.value)}
                  autoFocus
                />
              </motion.div>
            )}
          </AnimatePresence>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className="hidden sm:inline-flex text-brand-muted hover:bg-transparent"
          >
            <Search className="h-5 w-5" />
          </Button>

          <Button variant="ghost" size="icon" className="text-brand-muted hover:bg-transparent">
            <User className="h-5 w-5" />
          </Button>

          <Button 
            variant="ghost" 
            size="icon" 
            className="relative text-brand-muted hover:bg-transparent"
            onClick={onOpenCart}
          >
            <ShoppingBag className="h-5 w-5" />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 flex h-4 w-4 items-center justify-center rounded-none bg-brand-muted text-[9px] font-bold text-white">
                {cartCount}
              </span>
            )}
          </Button>
        </div>
      </div>
    </nav>
  );
}
