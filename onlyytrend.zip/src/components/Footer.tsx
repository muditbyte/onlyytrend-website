import { Facebook, Instagram, Twitter, Mail, MapPin, Phone, Wind } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-gray-100 bg-white py-20">
      <div className="container mx-auto px-4 md:px-12">
        <div className="grid grid-cols-1 gap-16 md:grid-cols-4">
          <div className="space-y-6">
            <div className="flex flex-col items-start gap-1">
              <Wind className="h-5 w-5 text-brand-muted" />
              <h3 className="font-serif text-2xl text-brand-muted tracking-[0.1em]">ONLYYTREND</h3>
            </div>
            <p className="text-sm text-gray-500 font-sans leading-relaxed">
              A curated destination for the modern gentleman. We specialize in high-end streetwear, luxury timepieces, and artisanal fragrances.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-brand-muted/40 hover:text-brand-muted transition-colors"><Instagram className="h-5 w-5" /></a>
              <a href="#" className="text-brand-muted/40 hover:text-brand-muted transition-colors"><Facebook className="h-5 w-5" /></a>
              <a href="#" className="text-brand-muted/40 hover:text-brand-muted transition-colors"><Twitter className="h-5 w-5" /></a>
            </div>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-[10px] font-sans font-bold uppercase tracking-[0.2em] text-brand-muted/60">Collections</h4>
            <ul className="space-y-3 text-[13px] text-gray-500 font-sans">
              <li><a href="#" className="hover:text-brand-muted transition-colors">All Collections</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">New Arrivals</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">Shoes & Kicks</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">Apparel</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">Accessories</a></li>
            </ul>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-[10px] font-sans font-bold uppercase tracking-[0.2em] text-brand-muted/60">Client Service</h4>
            <ul className="space-y-3 text-[13px] text-gray-500 font-sans">
              <li><a href="#" className="hover:text-brand-muted transition-colors">Shipping & Delivery</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">Returns & Exchanges</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">Size Guide</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-brand-muted transition-colors">Terms of Service</a></li>
            </ul>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-[10px] font-sans font-bold uppercase tracking-[0.2em] text-brand-muted/60">Boutique</h4>
            <ul className="space-y-4 text-[13px] text-gray-500 font-sans">
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 text-brand-muted/40" />
                <span>Jaipur, Rajasthan, India</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-brand-muted/40" />
                <span>+91 6367322260</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-brand-muted/40" />
                <span>mbhatinhr@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-20 border-t border-gray-50 pt-10 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-gray-400 uppercase tracking-widest font-sans">
          <p>© 2026 ONLYYTREND. ALL RIGHTS RESERVED.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-brand-muted transition-colors">PRIVACY</a>
            <a href="#" className="hover:text-brand-muted transition-colors">COOKIES</a>
            <a href="#" className="hover:text-brand-muted transition-colors">ACCESSIBILITY</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
