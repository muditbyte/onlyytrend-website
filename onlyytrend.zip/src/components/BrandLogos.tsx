import React from 'react';

const brands = [
  "Manyavar", "Blackberrys", "Van Heusen", "Louis Philippe", "Allen Solly",
  "Killer", "Spykar", "Mufti", "Flying Machine", "French Connection",
  "Levi's", "U.S. Polo Assn.", "Crimsoune Club", "Rare Rabbit", "Celio"
];

export default function BrandLogos() {
  return (
    <section className="bg-white py-10 border-b border-gray-100">
      <div className="container mx-auto px-4 md:px-12">
        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-6">
          {brands.map((brand, index) => (
            <React.Fragment key={brand}>
              <div className="flex items-center justify-center">
                <span className="font-sans text-[10px] md:text-[11px] font-bold tracking-[0.2em] uppercase text-black/70 hover:text-black transition-colors cursor-default whitespace-nowrap">
                  {brand}
                </span>
              </div>
              {index < brands.length - 1 && (
                <div className="h-4 w-[1px] bg-gray-200 hidden sm:block" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </section>
  );
}
