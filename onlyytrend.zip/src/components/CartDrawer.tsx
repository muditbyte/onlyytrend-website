import { CartItem } from '@/src/types';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
}

export default function CartDrawer({ isOpen, onClose, items, onUpdateQuantity, onRemove }: CartDrawerProps) {
  const subtotal = items.reduce((acc, item) => acc + (item.discountPrice || item.price) * item.quantity, 0);

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="flex w-full flex-col sm:max-w-md rounded-none border-l border-gray-100">
        <SheetHeader className="space-y-4">
          <SheetTitle className="flex items-center gap-3 font-serif text-2xl text-brand-muted">
            <ShoppingBag className="h-5 w-5" />
            Your Bag ({items.length})
          </SheetTitle>
          <Separator className="bg-gray-50" />
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center space-y-6">
            <div className="bg-gray-50 p-8">
              <ShoppingBag className="h-12 w-12 text-gray-300" />
            </div>
            <div className="text-center space-y-2">
              <p className="text-sm text-gray-500 font-sans uppercase tracking-widest">Your bag is empty</p>
              <p className="text-xs text-gray-400 font-sans">Discover our latest arrivals</p>
            </div>
            <Button variant="outline" className="rounded-none border-gray-200 text-[10px] tracking-widest uppercase px-8" onClick={onClose}>Start Shopping</Button>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 pr-4">
              <div className="space-y-8 py-6">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-6">
                    <div className="h-32 w-24 flex-shrink-0 overflow-hidden bg-gray-50">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover transition-transform duration-500 hover:scale-110"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="flex flex-1 flex-col justify-between py-1">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <h4 className="text-sm font-serif text-brand-muted leading-tight">{item.name}</h4>
                          <p className="text-[10px] text-gray-400 font-sans uppercase tracking-widest">{item.category}</p>
                        </div>
                        <p className="text-sm font-sans font-medium text-brand-muted">
                          ₹{((item.discountPrice || item.price) * item.quantity).toLocaleString('en-IN')}
                        </p>
                      </div>
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center border border-gray-100 px-2 py-1">
                          <button 
                            className="p-1 text-gray-400 hover:text-brand-muted disabled:opacity-20 transition-colors"
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="w-8 text-center text-xs font-sans text-brand-muted">{item.quantity}</span>
                          <button 
                            className="p-1 text-gray-400 hover:text-brand-muted transition-colors"
                            onClick={() => onUpdateQuantity(item.id, 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-gray-300 hover:text-destructive hover:bg-transparent transition-colors"
                          onClick={() => onRemove(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <SheetFooter className="mt-auto pt-8">
              <div className="w-full space-y-6">
                <Separator className="bg-gray-50" />
                <div className="space-y-2">
                  <div className="flex justify-between text-sm font-sans text-gray-500 uppercase tracking-widest">
                    <span>Subtotal</span>
                    <span className="text-brand-muted font-medium">₹{subtotal.toLocaleString('en-IN')}</span>
                  </div>
                  <p className="text-[10px] text-gray-400 font-sans italic">Shipping and taxes calculated at checkout.</p>
                </div>
                <Button className="w-full rounded-none bg-brand-muted py-7 text-[11px] uppercase tracking-[0.2em] text-white hover:bg-brand-muted/90 transition-all duration-300">
                  Proceed to Checkout
                </Button>
              </div>
            </SheetFooter>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
