import React from 'react';
import { Product } from '../types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Eye } from 'lucide-react';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails?: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onViewDetails }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="group overflow-hidden border-none bg-transparent shadow-none rounded-none">
        <CardContent className="relative p-0">
          <div className="aspect-[3/4] overflow-hidden bg-gray-50">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          </div>
          
          <div className="absolute top-0 left-0 flex flex-col gap-1">
            {product.isNew && (
              <Badge className="bg-brand-muted text-white hover:bg-brand-muted rounded-none text-[10px] tracking-widest px-2 py-0.5">NEW</Badge>
            )}
            {product.isSale && (
              <Badge variant="destructive" className="rounded-none text-[10px] tracking-widest px-2 py-0.5">SALE</Badge>
            )}
          </div>

          <div className="absolute inset-0 flex items-center justify-center gap-4 bg-white/40 opacity-0 backdrop-blur-[1px] transition-all duration-500 group-hover:opacity-100">
            <Button 
              size="icon" 
              variant="secondary" 
              className="h-12 w-12 rounded-none bg-white text-brand-muted hover:bg-brand-muted hover:text-white shadow-sm transition-all duration-300"
              onClick={() => onAddToCart(product)}
            >
              <ShoppingCart className="h-5 w-5" />
            </Button>
            <Button 
              size="icon" 
              variant="secondary" 
              className="h-12 w-12 rounded-none bg-white text-brand-muted hover:bg-brand-muted hover:text-white shadow-sm transition-all duration-300"
              onClick={() => onViewDetails?.(product)}
            >
              <Eye className="h-5 w-5" />
            </Button>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col items-center px-0 py-6 text-center">
          <h3 className="font-serif text-base text-brand-muted tracking-tight group-hover:text-black transition-colors">{product.name}</h3>
          <div className="mt-1 flex items-center gap-3">
            {product.isSale && product.discountPrice ? (
              <>
                <span className="text-xs font-sans font-bold text-black">₹{product.discountPrice.toLocaleString('en-IN')}</span>
                <span className="text-[10px] font-sans text-gray-400 line-through">₹{product.price.toLocaleString('en-IN')}</span>
              </>
            ) : (
              <span className="text-xs font-sans font-bold text-black">₹{product.price.toLocaleString('en-IN')}</span>
            )}
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ProductCard;
