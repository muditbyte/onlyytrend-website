import { Button } from '@/components/ui/button';
import { motion } from 'motion/react';
import { ArrowRight, Wind } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative h-[90vh] w-full overflow-hidden bg-gray-100">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1490114538077-0a7f8cb49891?q=80&w=2000&auto=format&fit=crop"
          alt="ONLYYTREND Collection"
          className="h-full w-full object-cover object-center"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>

      {/* Content Overlay */}
      <div className="relative flex h-full flex-col items-center justify-between py-12 px-4 text-center">
        {/* Top Logo (Mimicking the ad) */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center gap-0"
        >
          <Wind className="h-12 w-12 text-white drop-shadow-md mb-1" />
          <h2 className="font-serif text-5xl md:text-6xl text-white tracking-[0.25em] drop-shadow-lg leading-none">
            ONLYYTREND
          </h2>
        </motion.div>

        {/* Bottom Text */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="space-y-2 pb-8"
        >
          <div className="space-y-0">
            <h1 className="font-sans text-6xl md:text-9xl text-white font-bold tracking-tight uppercase drop-shadow-2xl leading-tight">
              NEW ARRIVAL
            </h1>
            <p className="font-sans text-4xl md:text-6xl text-white/90 font-light tracking-[0.15em] uppercase drop-shadow-xl leading-none">
              FOR NEW YOU
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
