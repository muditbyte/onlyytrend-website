import { useState, useMemo } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BrandLogos from './components/BrandLogos';
import ProductCard from './components/ProductCard';
import CartDrawer from './components/CartDrawer';
import Footer from './components/Footer';
import { PRODUCTS } from './constants';
import { Product, CartItem } from './types';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'shoes' | 'clothes' | 'accessories' | 'watches' | 'perfumes'>('all');

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === 'all' || product.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory]);

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item
      )
    );
  };

  const handleRemoveFromCart = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-white font-sans text-black selection:bg-black selection:text-white">
      <Navbar 
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)} 
        onOpenCart={() => setIsCartOpen(true)}
        onSearch={setSearchQuery}
      />
      
      <main>
        <Hero />
        <BrandLogos />
        
        <section className="container mx-auto pt-32 pb-20 px-4 md:px-6">
          <div className="mb-16 flex flex-col items-center justify-between gap-10 md:flex-row">
            <div className="space-y-4 text-center md:text-left">
              <h2 className="font-serif text-5xl md:text-6xl text-brand-muted tracking-tight">ONLYYTREND COLLECTION</h2>
              <p className="text-gray-500 font-sans uppercase tracking-widest text-xs">Curated selection for the modern gentleman</p>
            </div>
            
            <Tabs 
              defaultValue="all" 
              className="w-full max-w-2xl overflow-x-auto"
              onValueChange={(v) => setActiveCategory(v as any)}
            >
              <TabsList className="flex w-max min-w-full gap-8 bg-transparent p-0 border-b border-gray-100 rounded-none h-12">
                <TabsTrigger value="all" className="rounded-none px-0 border-b-2 border-transparent data-[state=active]:border-brand-muted data-[state=active]:bg-transparent data-[state=active]:shadow-none font-sans text-sm uppercase tracking-wider">All</TabsTrigger>
                <TabsTrigger value="shoes" className="rounded-none px-0 border-b-2 border-transparent data-[state=active]:border-brand-muted data-[state=active]:bg-transparent data-[state=active]:shadow-none font-sans text-sm uppercase tracking-wider">Shoes</TabsTrigger>
                <TabsTrigger value="clothes" className="rounded-none px-0 border-b-2 border-transparent data-[state=active]:border-brand-muted data-[state=active]:bg-transparent data-[state=active]:shadow-none font-sans text-sm uppercase tracking-wider">Clothes</TabsTrigger>
                <TabsTrigger value="accessories" className="rounded-none px-0 border-b-2 border-transparent data-[state=active]:border-brand-muted data-[state=active]:bg-transparent data-[state=active]:shadow-none font-sans text-sm uppercase tracking-wider">Accessories</TabsTrigger>
                <TabsTrigger value="watches" className="rounded-none px-0 border-b-2 border-transparent data-[state=active]:border-brand-muted data-[state=active]:bg-transparent data-[state=active]:shadow-none font-sans text-sm uppercase tracking-wider">Watches</TabsTrigger>
                <TabsTrigger value="perfumes" className="rounded-none px-0 border-b-2 border-transparent data-[state=active]:border-brand-muted data-[state=active]:bg-transparent data-[state=active]:shadow-none font-sans text-sm uppercase tracking-wider">Perfumes</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
            <AnimatePresence mode="popLayout">
              {filteredProducts.map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onAddToCart={handleAddToCart}
                  onViewDetails={() => {}} 
                />
              ))}
            </AnimatePresence>
          </div>

          {filteredProducts.length === 0 && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-20 text-center"
            >
              <p className="text-lg text-gray-500">No products found matching your criteria.</p>
              <button 
                onClick={() => {setSearchQuery(''); setActiveCategory('all');}}
                className="mt-4 text-sm font-bold underline underline-offset-4"
              >
                Clear all filters
              </button>
            </motion.div>
          )}
        </section>

        <section className="bg-white py-24 border-t border-gray-100">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid grid-cols-1 items-center gap-16 lg:grid-cols-2">
              <div className="space-y-8">
                <h2 className="font-serif text-5xl md:text-6xl text-brand-muted tracking-tight">OUR PHILOSOPHY</h2>
                <p className="text-lg text-gray-600 leading-relaxed font-sans">
                  At ONLYYTREND, we believe that style is a superpower for the next generation. Our mission is to provide boys with high-quality, trending fashion that empowers confidence and creativity.
                </p>
                <div className="grid grid-cols-2 gap-12 pt-4">
                  <div className="space-y-2">
                    <h4 className="font-serif text-2xl text-brand-muted">Sustainable</h4>
                    <p className="text-sm text-gray-500 font-sans">Ethically sourced materials and responsible manufacturing processes.</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-serif text-2xl text-brand-muted">Timeless</h4>
                    <p className="text-sm text-gray-500 font-sans">Designs that transcend seasons, built to last a lifetime.</p>
                  </div>
                </div>
              </div>
              <div className="relative aspect-[4/5] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1200&auto=format&fit=crop" 
                  alt="Philosophy" 
                  className="h-full w-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemove={handleRemoveFromCart}
      />
    </div>
  );
}
