export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'shoes' | 'clothes' | 'accessories' | 'watches' | 'perfumes';
  description: string;
  image: string;
  isNew?: boolean;
  isSale?: boolean;
  discountPrice?: number;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
}
