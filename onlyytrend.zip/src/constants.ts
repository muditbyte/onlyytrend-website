import { Product } from './types';

export const PRODUCTS: Product[] = [
  // SHOES
  {
    id: 's1',
    name: 'Nike Dunk Low Retro',
    price: 8999,
    category: 'shoes',
    description: 'Classic basketball silhouette with premium leather overlays.',
    image: 'https://images.unsplash.com/photo-1600054881939-1995f73a126c?q=80&w=800&auto=format&fit=crop',
    isNew: true
  },
  {
    id: 's2',
    name: 'New Balance 550',
    price: 11999,
    category: 'shoes',
    description: 'Vintage-inspired lifestyle sneaker with a clean, minimalist look.',
    image: 'https://images.unsplash.com/photo-1636718282214-0b414068536e?q=80&w=800&auto=format&fit=crop',
    isSale: true,
    discountPrice: 9999
  },
  {
    id: 's3',
    name: 'Air Jordan 1 High OG',
    price: 15999,
    category: 'shoes',
    description: 'The iconic sneaker that started it all. Premium materials and timeless design.',
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 's4',
    name: 'Onitsuka Tiger Mexico 66',
    price: 7999,
    category: 'shoes',
    description: 'Classic slim-profile sneaker with iconic stripes.',
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 's5',
    name: 'Adidas Samba OG',
    price: 9999,
    category: 'shoes',
    description: 'The terrace classic. Suede and leather construction.',
    image: 'https://images.unsplash.com/photo-1612902377756-414b2139d5e2?q=80&w=800&auto=format&fit=crop',
    isNew: true
  },

  // CLOTHES
  {
    id: 'c1',
    name: 'Louis Philippe Premium Polo',
    price: 2499,
    category: 'clothes',
    description: 'Breathable premium cotton polo shirt with tailored fit from Louis Philippe.',
    image: 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=800&auto=format&fit=crop',
    isNew: true
  },
  {
    id: 'c2',
    name: 'Van Heusen Formal Shirt',
    price: 1999,
    category: 'clothes',
    description: 'Classic slim-fit formal shirt with non-iron finish from Van Heusen.',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'c3',
    name: 'Levi\'s 511 Slim Fit Denim',
    price: 3999,
    category: 'clothes',
    description: 'Premium raw selvedge denim with a modern slim cut from Levi\'s.',
    image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?q=80&w=800&auto=format&fit=crop',
    isSale: true,
    discountPrice: 3499
  },
  {
    id: 'c4',
    name: 'Rare Rabbit Utility Cargo',
    price: 4499,
    category: 'clothes',
    description: 'Multi-pocket cargo pants with durable ripstop fabric from Rare Rabbit.',
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'c5',
    name: 'Allen Solly Linen Shirt',
    price: 2999,
    category: 'clothes',
    description: 'Lightweight linen blend shirt perfect for warm weather from Allen Solly.',
    image: 'https://images.unsplash.com/photo-1598033129183-c4f50c7176c8?q=80&w=800&auto=format&fit=crop'
  },

  // ACCESSORIES (SUNGLASSES & WALLETS)
  {
    id: 'a1',
    name: 'Classic Aviator Sunglasses',
    price: 4999,
    category: 'accessories',
    description: 'Timeless aviator style with polarized lenses and gold frame.',
    image: 'https://images.unsplash.com/photo-1511499767390-a8a196109e92?q=80&w=800&auto=format&fit=crop',
    isNew: true
  },
  {
    id: 'a2',
    name: 'Luxury Leather Cardholder',
    price: 2499,
    category: 'accessories',
    description: 'Genuine calfskin leather cardholder with 6 slots.',
    image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'a3',
    name: 'Wayfarer Style Shades',
    price: 3999,
    category: 'accessories',
    description: 'Modern wayfarer silhouette with matte black finish.',
    image: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?q=80&w=800&auto=format&fit=crop',
    isSale: true,
    discountPrice: 2999
  },
  {
    id: 'a4',
    name: 'Bifold Leather Wallet',
    price: 3499,
    category: 'accessories',
    description: 'Classic bifold design with premium textured leather.',
    image: 'https://images.unsplash.com/photo-1606503170916-5e541d3c2a7e?q=80&w=800&auto=format&fit=crop'
  },

  // WATCHES
  {
    id: 'w1',
    name: 'Tissot PRX Powermatic 80',
    price: 65000,
    category: 'watches',
    description: 'Integrated bracelet sports watch with Swiss automatic movement.',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop',
    isNew: true
  },
  {
    id: 'w2',
    name: 'Fossil Heritage Chronograph',
    price: 12999,
    category: 'watches',
    description: 'Vintage-inspired chronograph with leather strap.',
    image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'w3',
    name: 'Patek Philippe Nautilus Style',
    price: 150000,
    category: 'watches',
    description: 'Luxury sports watch with iconic octagonal bezel.',
    image: 'https://images.unsplash.com/photo-1547996160-81dfa63595aa?q=80&w=800&auto=format&fit=crop'
  },

  // PERFUMES
  {
    id: 'p1',
    name: 'Creed Aventus',
    price: 28000,
    category: 'perfumes',
    description: 'Sophisticated fruity-woody fragrance for the modern man.',
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?q=80&w=800&auto=format&fit=crop',
    isNew: true
  },
  {
    id: 'p2',
    name: 'Hugo Boss Bottled',
    price: 6999,
    category: 'perfumes',
    description: 'Fresh and sharp fragrance with a warm woody base.',
    image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'p3',
    name: 'Bleu de Chanel',
    price: 12000,
    category: 'perfumes',
    description: 'A woody, aromatic fragrance for the man who defies convention.',
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?q=80&w=800&auto=format&fit=crop',
    isSale: true,
    discountPrice: 10500
  }
];
